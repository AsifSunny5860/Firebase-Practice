package com.example.myproject;


import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class ComfortFragment extends Fragment implements ClickListener{
    private List<House> houseList = new ArrayList<>();

    private RecyclerView recyclerviewID;

    public ComfortFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_comfort, container, false);

        prepareItem();


        recyclerviewID = view.findViewById(R.id.recyclerviewID);
        recyclerviewID.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerviewID.setItemAnimator(new DefaultItemAnimator());

        ComfortListAdapter comfortListAdapter = new ComfortListAdapter(houseList);
        comfortListAdapter.setClickListener(this);
        recyclerviewID.setAdapter(comfortListAdapter);


        return view;
    }

    private void prepareItem() {
        houseList.add(new House("Guha-The kave kitchen", "01985285900", R.drawable.guhaa));
        houseList.add(new House("Ozz cafe","01999-027007",R.drawable.ozz));
        houseList.add(new House("Cafe Cherry Drops","01932-928773",R.drawable.cp0));
        houseList.add(new House("The Mirror",  "01985285900", R.drawable.mirror));
        houseList.add(new House("Chilekotha", "01985285900", R.drawable.chilekotha));
        houseList.add(new House("Hangout",  "01985285900", R.drawable.hangout));
    }

    @Override
    public void itemClicked(View v, int adapterPosition) {

        if (adapterPosition == 0) {
            Intent intent = new Intent(getActivity(), Guha.class);
            startActivity(intent);
        } else if (adapterPosition == 1) {
            Intent intent = new Intent(getActivity(), OzzCafe.class);
            startActivity(intent);
        } else if (adapterPosition == 2) {
            Intent intent = new Intent(getActivity(), CherryDrops.class);
            startActivity(intent);
        }else if(adapterPosition==3) {
            Intent intent = new Intent(getActivity(), Mirror.class);
            startActivity(intent);
        } else if(adapterPosition==4) {
            Intent intent = new Intent(getActivity(), Chilekotha.class);
            startActivity(intent);
        } else if(adapterPosition==5) {
            Intent intent = new Intent(getActivity(), Hangout.class);
            startActivity(intent);
        }
        else {
            System.out.println("position...." + adapterPosition);

        }

    }
}

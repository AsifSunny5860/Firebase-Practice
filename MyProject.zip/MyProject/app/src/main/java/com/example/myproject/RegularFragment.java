package com.example.myproject;


import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class RegularFragment extends Fragment implements ClickListener{

    private List<House> houseList = new ArrayList<>();
    private RecyclerView recyclerviewID;


    public RegularFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_regular, container, false);

        prepareItem();

        recyclerviewID=view.findViewById(R.id.recyclerviewID);
        recyclerviewID.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerviewID.setItemAnimator(new DefaultItemAnimator());

        RegularListAdapter regularListAdapter = new RegularListAdapter(houseList);
        regularListAdapter.setClickListener(this);
        recyclerviewID.setAdapter(regularListAdapter);


        return view;
    }

    private void prepareItem() {
        houseList.add(new House("Pizzaburg","01908-327868",R.drawable.pizzburg));
        houseList.add(new House("cheese factory","01745-218466",R.drawable.cheese));
        houseList.add(new House("peri pasta","01643-395224",R.drawable.peri));
        houseList.add(new House("Kazi Asparagus Food Island","01974-062624",R.drawable.kazi));
    }

    @Override
    public void itemClicked(View v, int adapterPosition) {

        if(adapterPosition==0) {
            Intent intent = new Intent(getActivity(), Pizzaburg.class);
            startActivity(intent);
        }
        else if(adapterPosition==1) {
            Intent intent = new Intent(getActivity(), CheeseFactory.class);
            startActivity(intent);
        } else if(adapterPosition==2) {
            Intent intent = new Intent(getActivity(), CheeseFactory.class);
            startActivity(intent);
        } else if(adapterPosition==3) {
            Intent intent = new Intent(getActivity(), CheeseFactory.class);
            startActivity(intent);
        } else {
            System.out.println("position...."+adapterPosition);

        }

    }
}

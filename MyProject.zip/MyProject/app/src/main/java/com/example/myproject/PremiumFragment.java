package com.example.myproject;


import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class PremiumFragment extends Fragment implements ClickListener {

    private List<House> houseList = new ArrayList<>();

    private RecyclerView recyclerviewID;
    private CustomAdapter customAdapter;



    public PremiumFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       View view= inflater.inflate(R.layout.fragment_premium, container, false);

        prepareItem();

        recyclerviewID = view.findViewById(R.id.recyclerviewID);
        recyclerviewID.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerviewID.setItemAnimator(new DefaultItemAnimator());

        CustomAdapter customAdapter = new CustomAdapter(getContext(), houseList);
        customAdapter.setClickListener(this);

        recyclerviewID.setAdapter(customAdapter);



        return view;
    }

    private void prepareItem() {
        houseList.add(new House("Nandos", "01985285900", R.drawable.nandoso));
        houseList.add(new House("Gloria Jeans", "01674933262", R.drawable.gloria));
        houseList.add(new House("The Green Lounge Cafe", "01674833500", R.drawable.green_lounge));
        houseList.add(new House("Picasso", "01676282496", R.drawable.pc15));
        houseList.add(new House("Burger King", "01611112222", R.drawable.burger));
    }

    @Override
    public void itemClicked(View v, int adapterPosition) {


        if (adapterPosition == 0) {
            Intent intent = new Intent(getActivity(), Nandos.class);
            startActivity(intent);
        } else if (adapterPosition == 1) {
            Intent intent = new Intent(getActivity(), Gloria.class);
            startActivity(intent);
        } else if (adapterPosition == 2) {
            Intent intent = new Intent(getActivity(), Greenlounge.class);
            startActivity(intent);
        } else if (adapterPosition == 3) {
            Intent intent = new Intent(getActivity(), Picasso.class);
            startActivity(intent);
        } else if (adapterPosition == 4) {
            Intent intent = new Intent(getActivity(), Burger.class);
            startActivity(intent);
        } else {
            System.out.println("position...." + adapterPosition);

        }


    }
}

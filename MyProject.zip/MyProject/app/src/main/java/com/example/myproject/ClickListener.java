package com.example.myproject;

import android.view.View;

    public interface ClickListener {
     void itemClicked(View v, int adapterPosition);
 }
